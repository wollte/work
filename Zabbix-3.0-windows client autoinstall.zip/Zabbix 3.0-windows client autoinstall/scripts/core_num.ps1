# Powershell script обнаруживающий число логических ядер через WMI и рапортующий об этом  через JSON
# сообщения которые понимает Zabbix для процесса Low Level Discovery объектов.
#http://habrahabr.ru/post/194980/

$items = Get-WmiObject Win32_PerfFormattedData_PerfOS_Processor | select name  |where-object {$_.name -ne '_Total'}

write-host -NoNewline "{"
write-host -NoNewline "`"data`":["

$line =  "{`"{#PROCNUM}`":`"" + $items[0].Name + "`"}"
write-host -NoNewline $line

for($c = 1; $c -lt $items.Count; ++$c) {
 $line =  ",{`"{#PROCNUM}`":`"" + $items[$c].Name + "`"}"
 write-host -NoNewline $line
}

write-host -NoNewline "]"
write-host -NoNewline "}"