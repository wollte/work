$diskList = &"C:\ZabbixAgent\tools\smartctl.exe" --scan
$diskList = $diskList -replace ", ", " "
$diskList = $diskList -split ' ' | Select-String "/dev/*"  | select -uniq

write-host -NoNewline "{"
write-host -NoNewline "`"data`":["

for ($i = 0; $i -le ($diskList.length - 1); $i += 1) 
{
	if($i -eq 0) 
	{
         
		 $line =  "{`"{#DISKNUM}`":`"" + $diskList[$i] + "`"}"
         
    }
	else 
	{
		$line =  ",{`"{#DISKNUM}`":`"" + $diskList[$i] + "`"}"
	}
	write-host -NoNewline $line
}

write-host -NoNewline "]"
write-host -NoNewline "}"